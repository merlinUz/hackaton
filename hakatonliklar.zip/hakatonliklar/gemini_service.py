"""
Gemini AI Service Module
Handles all interactions with Google Gemini API for mnemonic generation
"""

import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Try different import paths for compatibility
try:
    from google.genai import Client
    from google.genai.types import GenerateContentConfig
except ImportError:
    try:
        from google.genai import client as Client
        from google.genai.types import GenerateContentConfig
    except ImportError:
        raise ImportError(
            "Failed to import google-genai. Please run: pip install --upgrade google-genai"
        )

class GeminiService:
    """Service for generating mnemonics and examples using Gemini AI"""
    
    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY")
        if not self.api_key:
            raise ValueError("GEMINI_API_KEY not found in environment variables")
        
        self.client = Client(api_key=self.api_key)
        self.model = "gemini-3.1-flash-lite-preview"
    
    def generate_mnemonic(self, word: str) -> dict:
        """
        Generate a mnemonic story in Uzbek and an example sentence in English
        
        Args:
            word: The English word to learn
            
        Returns:
            dict containing:
            - word_en: Original English word
            - word_uz: Uzbek translation
            - mnemonic: Creative story in Uzbek
            - example: Natural English sentence using the word
        """
        
        prompt = f"""You are a creative language learning assistant specializing in mnemonic techniques.

For the English word "{word}", provide:

1. **Uzbek Translation**: The most common Uzbek translation of the word
2. **Mnemonic Story**: A creative, memorable story in Uzbek that helps remember the English word. The story should be engaging and create vivid mental imagery.
3. **Example Sentence**: A natural, everyday English sentence that clearly demonstrates the word's usage

Format your response EXACTLY as follows (keep the headers):

UZBEK: [Uzbek translation]
MNEMONIC: [Uzbek mnemonic story]
EXAMPLE: [English example sentence]

Important:
- The mnemonic must be in Uzbek language
- Make the story creative and memorable
- The example sentence should be natural and practical
- Do not include any explanations or extra text"""

        try:
            response = self.client.models.generate_content(
                model=self.model,
                contents=prompt,
                config=GenerateContentConfig(
                    temperature=0.8,
                    max_output_tokens=500
                )
            )
            
            # Parse the response
            return self._parse_response(word, response.text)
            
        except Exception as e:
            raise Exception(f"Failed to generate mnemonic: {str(e)}")
    
    def _parse_response(self, original_word: str, response_text: str) -> dict:
        """Parse the Gemini response into structured data"""
        
        lines = response_text.strip().split('\n')
        result = {
            "word_en": original_word,
            "word_uz": "",
            "mnemonic": "",
            "example": ""
        }
        
        for line in lines:
            line = line.strip()
            if line.startswith("UZBEK:"):
                result["word_uz"] = line.replace("UZBEK:", "").strip()
            elif line.startswith("MNEMONIC:"):
                result["mnemonic"] = line.replace("MNEMONIC:", "").strip()
            elif line.startswith("EXAMPLE:"):
                result["example"] = line.replace("EXAMPLE:", "").strip()
        
        # If parsing failed, provide fallback
        if not result["word_uz"]:
            result["word_uz"] = f"[Translation of {original_word}]"
        if not result["mnemonic"]:
            result["mnemonic"] = f'Mnemonika uchun "{original_word}" so\'zini yodlang'
        if not result["example"]:
            result["example"] = f"This is an example using the word {original_word}."
        
        return result

# Global service instance
_gemini_service = None

def get_gemini_service() -> GeminiService:
    """Get or create the Gemini service singleton"""
    global _gemini_service
    if _gemini_service is None:
        _gemini_service = GeminiService()
    return _gemini_service
