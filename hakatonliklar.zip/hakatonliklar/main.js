// ── LANDING PAGE & NAVIGATION ──

function enterMainApp() {
    // Show main navigation
    const mainNav = document.getElementById('mainNav');
    if (mainNav) mainNav.style.display = 'flex';
    
    // Show features section
    const mainFeatures = document.getElementById('mainFeatures');
    if (mainFeatures) mainFeatures.style.display = 'block';
    
    // Update landing button to show we're in the app
    const landingBtn = document.querySelector('.btn-landing');
    if (landingBtn) {
        landingBtn.innerHTML = 'Mashqlar boshlandi! <i class="fas fa-check"></i>';
        landingBtn.disabled = true;
        landingBtn.style.opacity = '0.7';
    }
    
    showToast('Xush kelibsiz! Mashqlarni boshlang 🎯');
}

// ── Add this to the existing showSection function ──
function showSection(name) {
    ['home','app','auth','memory-game','lingo-games','team','history','settings','play-learn','mnemonika'].forEach(s => {
        const el = document.getElementById(s + '-section');
        if (el) el.style.display = 'none';
        const nav = document.getElementById('nav-' + s);
        if (nav) nav.classList.remove('active');
    });

    const section = document.getElementById(name + '-section');
    if (!section) return;

    const flexSections = ['app','auth','memory-game','lingo-games','settings','history','team','play-learn','mnemonika'];
    section.style.display = flexSections.includes(name) ? 'flex' : 'block';

    const nav = document.getElementById('nav-' + name);
    if (nav) nav.classList.add('active');

    if (name === 'app')     setTimeout(() => document.getElementById('wordInput').focus(), 100);
    if (name === 'memory-game') initializeMemoryGame();

    clearAuthError('authError');
}

// ── LINGO PLAY GAMES ──
let lingoCurrentGame = null;
let lingoLevel = 'medium';

function changeLingoLevel() {
    const select = document.getElementById('lingoLevelSelect');
    lingoLevel = select.value;
}

function startLingoGame(gameType) {
    lingoCurrentGame = gameType;
    const content = document.getElementById('lingoGameContent');
    const area = document.getElementById('lingoGameArea');
    const gamesGrid = document.querySelector('.lingo-games-grid');
    
    gamesGrid.style.display = 'none';
    content.style.display = 'block';
    
    switch(gameType) {
        case 'word-match':
            createWordMatchGame(area);
            break;
        case 'word-guess':
            createWordGuessGame(area);
            break;
        case 'sentence-fill':
            createSentenceFillGame(area);
            break;
        case 'spelling':
            createSpellingGame(area);
            break;
        case 'listening':
            createListeningGame(area);
            break;
        case 'pronunciation':
            createPronunciationGame(area);
            break;
    }
}

function closeLingoGame() {
    lingoCurrentGame = null;
    document.getElementById('lingoGameContent').style.display = 'none';
    document.querySelector('.lingo-games-grid').style.display = 'grid';
}

// ── Word Match Game ──
function createWordMatchGame(container) {
    const words = [
        { en: 'Apple', uz: 'Olma' },
        { en: 'Book', uz: 'Kitob' },
        { en: 'Cat', uz: 'Mushuk' },
        { en: 'Dog', uz: 'It' },
        { en: 'Elephant', uz: 'Fil' }
    ];

    let score = 0;
    let gameWords = [...words].sort(() => Math.random() - 0.5);

    container.innerHTML = `
        <div class="lingo-game-header">
            <h2>So'zni Mosla</h2>
            <div class="game-score">Bal: <span id="matchScore">0</span>/${gameWords.length}</div>
        </div>
        <div class="word-match-game">
            <div class="match-column" id="englishWords"></div>
            <div class="match-arrows"></div>
            <div class="match-column" id="uzbekWords"></div>
        </div>
        <button class="btn-game-start" onclick="closeLingoGame()">Tugatish</button>
    `;

    const enContainer = document.getElementById('englishWords');
    const uzContainer = document.getElementById('uzbekWords');

    gameWords.forEach((word, idx) => {
        const enBtn = document.createElement('button');
        enBtn.className = 'match-btn en-btn';
        enBtn.textContent = word.en;
        enBtn.dataset.pair = idx;
        enBtn.onclick = () => selectMatchWord(enBtn, 'en');
        enContainer.appendChild(enBtn);
    });

    const shuffledUz = [...gameWords].sort(() => Math.random() - 0.5);
    shuffledUz.forEach((word, idx) => {
        const uzBtn = document.createElement('button');
        uzBtn.className = 'match-btn uz-btn';
        uzBtn.textContent = word.uz;
        uzBtn.dataset.word = word.en;
        uzBtn.onclick = () => selectMatchWord(uzBtn, 'uz');
        uzContainer.appendChild(uzBtn);
    });
}

let selectedEnWord = null;

function selectMatchWord(btn, type) {
    if (type === 'en') {
        document.querySelectorAll('.en-btn').forEach(b => b.classList.remove('selected'));
        btn.classList.add('selected');
        selectedEnWord = btn;
    } else if (selectedEnWord) {
        if (btn.dataset.word === selectedEnWord.textContent) {
            btn.classList.add('matched');
            selectedEnWord.classList.add('matched');
            document.getElementById('matchScore').textContent = 
                document.querySelectorAll('.uz-btn.matched').length;
            showToast('To\'g\'ri! 🎉');
        } else {
            showToast('Noto\'g\'ri! Qayta urinib ko\'ring.');
        }
        selectedEnWord = null;
    }
}

// ── Word Guess Game ──
function createWordGuessGame(container) {
    const words = ['APPLE', 'BOOK', 'COMPUTER', 'ELEPHANT', 'FLOWER', 'GUITAR'];
    const randomWord = words[Math.floor(Math.random() * words.length)];
    const hiddenWord = randomWord.split('').map(() => '_').join(' ');

    container.innerHTML = `
        <div class="lingo-game-header">
            <h2>So'zni Topish</h2>
            <div class="game-score">Urinishlar: <span id="guessAttempts">6</span></div>
        </div>
        <div class="word-guess-game">
            <div class="hidden-word" id="hiddenWord">${hiddenWord}</div>
            <div class="letter-buttons" id="letterButtons"></div>
            <div id="guessMessage" class="guess-message"></div>
        </div>
        <button class="btn-game-start" onclick="closeLingoGame()">Tugatish</button>
    `;

    let attempts = 6;
    let guessedLetters = [];
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
    const letterBtns = document.getElementById('letterButtons');

    alphabet.forEach(letter => {
        const btn = document.createElement('button');
        btn.className = 'letter-btn';
        btn.textContent = letter;
        btn.onclick = () => guessLetter(letter, randomWord, btn);
        letterBtns.appendChild(btn);
    });
}

function guessLetter(letter, word, btn) {
    btn.disabled = true;
    if (word.includes(letter)) {
        showToast('To\'g\'ri! ✓');
        updateHiddenWord(letter, word);
    } else {
        showToast('Noto\'g\'ri! ✗');
        document.getElementById('guessAttempts').textContent--;
    }
}

function updateHiddenWord(letter, word) {
    const hidden = document.getElementById('hiddenWord');
    let display = '';
    word.split('').forEach((char, idx) => {
        display += (char === letter || guessedLetters.includes(char)) ? char + ' ' : '_ ';
    });
    hidden.textContent = display;
}

// ── Sentence Fill Game ──
function createSentenceFillGame(container) {
    const sentences = [
        { sentence: 'I ___ a student.', answer: 'am', options: ['am', 'is', 'are'] },
        { sentence: 'She ___ to school every day.', answer: 'goes', options: ['go', 'goes', 'going'] },
        { sentence: 'They ___ playing football.', answer: 'are', options: ['is', 'are', 'am'] }
    ];

    const random = sentences[Math.floor(Math.random() * sentences.length)];

    container.innerHTML = `
        <div class="lingo-game-header">
            <h2>Gap to'ldirish</h2>
        </div>
        <div class="sentence-fill-game">
            <p class="sentence">${random.sentence}</p>
            <div class="sentence-options" id="sentenceOptions"></div>
            <div id="fillMessage" class="guess-message"></div>
        </div>
        <button class="btn-game-start" onclick="closeLingoGame()">Tugatish</button>
    `;

    const optionsDiv = document.getElementById('sentenceOptions');
    random.options.forEach(opt => {
        const btn = document.createElement('button');
        btn.className = 'sentence-option-btn';
        btn.textContent = opt;
        btn.onclick = () => checkFillAnswer(opt, random.answer, btn);
        optionsDiv.appendChild(btn);
    });
}

function checkFillAnswer(selected, correct, btn) {
    if (selected === correct) {
        btn.classList.add('correct');
        showToast('To\'g\'ri! 🎉');
        document.querySelectorAll('.sentence-option-btn').forEach(b => b.disabled = true);
    } else {
        btn.classList.add('incorrect');
        showToast('Noto\'g\'ri! Qayta urinib ko\'ring.');
    }
}

// ── Spelling Game ──
function createSpellingGame(container) {
    const words = [
        { word: 'Beautiful', hint: 'Chiroyli' },
        { word: 'Necessary', hint: 'Zarur' },
        { word: 'Successful', hint: 'Muvaffaqiyatli' }
    ];

    const random = words[Math.floor(Math.random() * words.length)];

    container.innerHTML = `
        <div class="lingo-game-header">
            <h2>Imlo Mashqi</h2>
            <p class="hint-text">Maslahat: ${random.hint}</p>
        </div>
        <div class="spelling-game">
            <input type="text" id="spellingInput" class="spelling-input" placeholder="So'zni kiriting...">
            <button class="btn-game-start" onclick="checkSpelling('${random.word}')">Tekshirish</button>
            <div id="spellingMessage" class="guess-message"></div>
        </div>
        <button class="btn-secondary" onclick="closeLingoGame()">Tugatish</button>
    `;

    document.getElementById('spellingInput').focus();
}

function checkSpelling(correctWord) {
    const input = document.getElementById('spellingInput');
    if (input.value.toLowerCase() === correctWord.toLowerCase()) {
        showToast('To\'g\'ri! 🎉');
        document.getElementById('spellingMessage').textContent = `✓ To'g'ri! So'z: ${correctWord}`;
        input.disabled = true;
    } else {
        showToast('Noto\'g\'ri! Qayta urinib ko\'ring.');
    }
}

// ── Listening Game ──
function createListeningGame(container) {
    const words = ['Apple', 'Book', 'Computer', 'Elephant', 'Flower'];
    const random = words[Math.floor(Math.random() * words.length)];

    container.innerHTML = `
        <div class="lingo-game-header">
            <h2>Eshitib Yozish</h2>
        </div>
        <div class="listening-game">
            <button class="btn-listen" onclick="playListeningWord('${random}')">
                <i class="fas fa-volume-up"></i> Eshiting
            </button>
            <input type="text" id="listeningInput" class="listening-input" placeholder="So'zni yozing...">
            <button class="btn-game-start" onclick="checkListening('${random}')">Tekshirish</button>
            <div id="listeningMessage" class="guess-message"></div>
        </div>
        <button class="btn-secondary" onclick="closeLingoGame()">Tugatish</button>
    `;

    document.getElementById('listeningInput').focus();
}

function playListeningWord(word) {
    const u = new SpeechSynthesisUtterance(word);
    u.lang = 'en-US';
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
}

function checkListening(correctWord) {
    const input = document.getElementById('listeningInput');
    if (input.value.toLowerCase() === correctWord.toLowerCase()) {
        showToast('To\'g\'ri! 🎉');
        input.disabled = true;
    } else {
        showToast('Noto\'g\'ri! Qayta eshiting.');
    }
}

// ── Pronunciation Game ──
function createPronunciationGame(container) {
    const words = ['Beautiful', 'Necessary', 'Pronunciation', 'Algorithm'];
    const random = words[Math.floor(Math.random() * words.length)];

    container.innerHTML = `
        <div class="lingo-game-header">
            <h2>Talaffuz Mashqi</h2>
        </div>
        <div class="pronunciation-game">
            <p class="pronunciation-word">${random}</p>
            <button class="btn-listen" onclick="playPronunciation('${random}')">
                <i class="fas fa-volume-up"></i> Eshiting
            </button>
            <button class="btn-record" onclick="startPronunciationRecord('${random}')">
                <i class="fas fa-microphone"></i> Ro'yxatdan O'tkazish
            </button>
            <div id="pronunciationFeedback" class="guess-message"></div>
        </div>
        <button class="btn-secondary" onclick="closeLingoGame()">Tugatish</button>
    `;
}

function playPronunciation(word) {
    const u = new SpeechSynthesisUtterance(word);
    u.lang = 'en-US';
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
}

function startPronunciationRecord(word) {
    showToast('Talaffuz ro\'yxatlandi! Mashq qilishni davom ettiring. 🎤');
}

// ── CARD AUDIO FUNCTION (with stopPropagation to prevent flip) ──

function playAudio(event) {
    // Prevent card from flipping when clicking audio button
    if (event) {
        event.preventDefault();
        event.stopPropagation();
    }
    
    const enDisplay = document.getElementById('enDisplay');
    if (!enDisplay) return;
    
    const word = enDisplay.textContent.trim();
    if (!word || word === '...') {
        showToast('Avval so\'z yarating!');
        return;
    }
    
    const u = new SpeechSynthesisUtterance(word);
    u.lang = 'en-US';
    u.rate = 0.9;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
    
    // Visual feedback on button
    const btn = event?.target.closest('.audio-btn') || document.querySelector('.audio-btn');
    if (btn) {
        btn.classList.add('playing');
        btn.style.animation = 'pulse 0.5s ease 2';
        setTimeout(() => {
            btn.classList.remove('playing');
            btn.style.animation = '';
        }, 1000);
    }
}

// ── i18n TRANSLATION SYSTEM ──

const translations = {
    uz: {
        nav: { home: 'Asosiy', exercises: 'Mashqlar', mnemonika: 'Mnemonika', games: "O'yinlar", team: 'Jamoa', settings: 'Sozlamalar', login: 'Kirish' },
        app: { title: 'MNEMONIKA AI', placeholder: "So'z kiriting...", create: 'YARATISH', save: 'Saqlash', back: 'Orqaga' },
        games: { title: "O'YINLAR", matchGame: 'Moslash', hiddenWord: "Yashirin So'z", playLearn: "O'yna va O'rgan" },
        team: { title: 'Jamoa', lead: 'Loyiha Rahbari', designer: 'Dizayner', developer: 'Dasturchi' },
        mnemonika: { 
            title: 'MNEMONIKA', 
            subtitle: 'Xotirani kuchaytirish san\'ati va ilmi',
            whatIs: 'Mnemonika nima?',
            techniques: 'Asosiy Mnemonika Texnikalari',
            exercises: 'Mini Mashqlar',
            acronym: 'Akronim Yaratish',
            visualization: 'Tasavvur Qilish',
            association: 'Assotsiatsiya',
            rhyme: 'Qofiya'
        },
        common: { loading: 'Yuklanmoqda...', flipHint: 'Aylanish uchun bosing', flipBackHint: 'Orqaga qaytish uchun bosing' }
    },
    en: {
        nav: { home: 'Home', exercises: 'Exercises', mnemonika: 'Mnemonika', games: 'Games', team: 'Team', settings: 'Settings', login: 'Login' },
        app: { title: 'MNEMONIKA AI', placeholder: 'Enter a word...', create: 'CREATE', save: 'Save', back: 'Back' },
        games: { title: 'GAMES', matchGame: 'Match Game', hiddenWord: 'Hidden Word', playLearn: 'Play & Learn' },
        team: { title: 'Team', lead: 'Project Lead', designer: 'Designer', developer: 'Developer' },
        mnemonika: { 
            title: 'MNEMONIKA', 
            subtitle: 'The Art and Science of Memory Enhancement',
            whatIs: 'What is Mnemonics?',
            techniques: 'Basic Mnemonic Techniques',
            exercises: 'Mini Exercises',
            acronym: 'Create Acronym',
            visualization: 'Visualization',
            association: 'Association',
            rhyme: 'Rhyme'
        },
        common: { loading: 'Loading...', flipHint: 'Click to flip', flipBackHint: 'Click to flip back' }
    },
    ru: {
        nav: { home: 'Главная', exercises: 'Упражнения', mnemonika: 'Мнемоника', games: 'Игры', team: 'Команда', settings: 'Настройки', login: 'Вход' },
        app: { title: 'MNEMONIKA AI', placeholder: 'Введите слово...', create: 'СОЗДАТЬ', save: 'Сохранить', back: 'Назад' },
        games: { title: 'ИГРЫ', matchGame: 'Найди пару', hiddenWord: 'Скрытое слово', playLearn: 'Играй и Учись' },
        team: { title: 'Команда', lead: 'Руководитель', designer: 'Дизайнер', developer: 'Разработчик' },
        mnemonika: { 
            title: 'МНЕМОНИКА', 
            subtitle: 'Искусство и наука улучшения памяти',
            whatIs: 'Что такое мнемоника?',
            techniques: 'Основные мнемонические техники',
            exercises: 'Мини упражнения',
            acronym: 'Создать акроним',
            visualization: 'Визуализация',
            association: 'Ассоциация',
            rhyme: 'Рифма'
        },
        common: { loading: 'Загрузка...', flipHint: 'Нажмите, чтобы перевернуть', flipBackHint: 'Нажмите, чтобы вернуться' }
    }
};

let currentLanguage = localStorage.getItem('mn_language') || 'uz';
let currentTopic = localStorage.getItem('mn_topic') || 'general';

function setLanguage(lang) {
    if (translations[lang]) {
        currentLanguage = lang;
        localStorage.setItem('mn_language', lang);
        applyTranslations();
        showToast(`Til o'zgartirildi: ${lang.toUpperCase()}`);
    }
}

function setTopic(topic) {
    currentTopic = topic;
    localStorage.setItem('mn_topic', topic);
    showToast(`Mavzu: ${topic}`);
}

function selectSubject(subject) {
    const subjectNames = {
        'english': 'Ingliz tili',
        'math': 'Matematika',
        'science': 'Fizika & Kimyo',
        'biology': 'Biologiya',
        'it': 'IT & Dasturlash',
        'medicine': 'Tibbiyot'
    };
    
    currentTopic = subject;
    localStorage.setItem('mn_topic', subject);
    showToast(`Fan tanlandi: ${subjectNames[subject] || subject}`);
    showSection('app');
}

function t(key, section = 'common') {
    const keys = key.split('.');
    let value = translations[currentLanguage];
    for (const k of keys) {
        value = value?.[k];
    }
    return value || key;
}

function applyTranslations() {
    // Update placeholders
    const wordInput = document.getElementById('wordInput');
    if (wordInput) wordInput.placeholder = t('app.placeholder');
    
    // Update buttons
    const btnCreate = document.querySelector('.btn-create');
    if (btnCreate) btnCreate.textContent = t('app.create');
    
    // Update hints
    document.querySelectorAll('.hint').forEach(el => {
        if (el.closest('.flip-card-front')) {
            el.textContent = t('common.flipHint');
        } else if (el.closest('.flip-card-back')) {
            el.textContent = t('common.flipBackHint');
        }
    });
    
    // Update navigation text
    const navHome = document.getElementById('nav-home');
    if (navHome) navHome.textContent = t('nav.home');
    
    const navApp = document.getElementById('nav-app');
    if (navApp) navApp.textContent = t('nav.exercises');
    
    const navMnemonika = document.getElementById('nav-mnemonika');
    if (navMnemonika) navMnemonika.textContent = t('nav.mnemonika');
    
    const navTeam = document.getElementById('nav-team');
    if (navTeam) navTeam.textContent = t('nav.team');
}

// Apply translations on page load
document.addEventListener('DOMContentLoaded', function() {
    applyTranslations();
    applyTheme();
});

// ── DYNAMIC THEME SYSTEM ──

const themes = {
    dark: {
        '--neon-cyan': '#00f2ff',
        '--neon-purple': '#bc13fe',
        '--neon-green': '#00ff9d',
        '--bg-primary': '#0a0a0f',
        '--bg-secondary': '#12121a',
        '--bg-card': 'rgba(18, 18, 26, 0.8)'
    },
    light: {
        '--neon-cyan': '#00aa66',
        '--neon-purple': '#00aa66',
        '--neon-green': '#00aa66',
        '--bg-primary': '#f0f4f8',
        '--bg-secondary': '#ffffff',
        '--bg-card': 'rgba(255, 255, 255, 0.9)'
    },
    ocean: {
        '--neon-cyan': '#00d4ff',
        '--neon-purple': '#0077ff',
        '--neon-green': '#00ffaa',
        '--bg-primary': '#001a33',
        '--bg-secondary': '#002244',
        '--bg-card': 'rgba(0, 34, 68, 0.8)'
    },
    sunset: {
        '--neon-cyan': '#ff6b6b',
        '--neon-purple': '#ff8e53',
        '--neon-green': '#ff4757',
        '--bg-primary': '#2d1b2e',
        '--bg-secondary': '#3d2335',
        '--bg-card': 'rgba(61, 35, 53, 0.8)'
    }
};

let currentTheme = localStorage.getItem('mn_theme') || 'dark';

function setTheme(themeName) {
    if (!themes[themeName]) return;
    
    currentTheme = themeName;
    localStorage.setItem('mn_theme', themeName);
    applyTheme();
    
    // Update active button state
    document.querySelectorAll('.theme-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.theme === themeName) {
            btn.classList.add('active');
        }
    });
    
    showToast(`Mavzu o'zgartirildi: ${themeName}`);
}

function applyTheme() {
    const root = document.documentElement;
    const theme = themes[currentTheme];
    
    if (!theme) return;
    
    for (const [property, value] of Object.entries(theme)) {
        root.style.setProperty(property, value);
    }
}

// ── MINI-GAMES ──

// Game 1: Match the Mnemonic
let matchGameState = {
    words: [],
    selectedCards: [],
    matchedPairs: 0,
    totalPairs: 0
};

function startMatchGame() {
    const area = document.getElementById('playLearnGameArea');
    if (!area) return;
    
    // Sample words for demo - in production, fetch from user's saved words
    const sampleWords = [
        { word_en: 'Apple', word_uz: 'Olma', mnemonic: 'Olma yeb apple' },
        { word_en: 'Book', word_uz: 'Kitob', mnemonic: 'Kitobni book' },
        { word_en: 'Sun', word_uz: 'Quyosh', mnemonic: 'Quyosh sun' },
        { word_en: 'Water', word_uz: 'Suv', mnemonic: 'Suv water' }
    ];
    
    matchGameState.words = sampleWords;
    matchGameState.totalPairs = sampleWords.length;
    matchGameState.matchedPairs = 0;
    matchGameState.selectedCards = [];
    
    let cards = [];
    sampleWords.forEach((w, i) => {
        cards.push({ id: i, type: 'word', content: w.word_en, pairId: i });
        cards.push({ id: i + 100, type: 'mnemonic', content: w.word_uz, pairId: i });
    });
    
    // Shuffle cards
    cards.sort(() => Math.random() - 0.5);
    
    area.innerHTML = `
        <div class="mini-game-header">
            <h3>${t('games.matchGame')}</h3>
            <div class="game-score">${matchGameState.matchedPairs}/${matchGameState.totalPairs}</div>
        </div>
        <div class="match-grid" id="matchGrid"></div>
    `;
    
    const grid = document.getElementById('matchGrid');
    cards.forEach(card => {
        const cardEl = document.createElement('div');
        cardEl.className = 'match-card';
        cardEl.dataset.pairId = card.pairId;
        cardEl.dataset.cardId = card.id;
        cardEl.innerHTML = `<span class="card-content">${card.content}</span>`;
        cardEl.onclick = () => selectMatchCard(cardEl, card);
        grid.appendChild(cardEl);
    });
}

function selectMatchCard(cardEl, card) {
    if (cardEl.classList.contains('matched') || cardEl.classList.contains('selected')) return;
    
    cardEl.classList.add('selected');
    matchGameState.selectedCards.push({ el: cardEl, card: card });
    
    if (matchGameState.selectedCards.length === 2) {
        const [first, second] = matchGameState.selectedCards;
        
        if (first.card.pairId === second.card.pairId && first.card.id !== second.card.id) {
            // Match!
            first.el.classList.remove('selected');
            first.el.classList.add('matched');
            second.el.classList.remove('selected');
            second.el.classList.add('matched');
            
            matchGameState.matchedPairs++;
            document.querySelector('.game-score').textContent = 
                `${matchGameState.matchedPairs}/${matchGameState.totalPairs}`;
            
            showToast('To\'g\'ri! ✅');
            
            if (matchGameState.matchedPairs === matchGameState.totalPairs) {
                setTimeout(() => showToast('O\'yin tugadi! 🎉'), 500);
            }
        } else {
            // No match
            setTimeout(() => {
                first.el.classList.remove('selected');
                second.el.classList.remove('selected');
            }, 1000);
            showToast('Noto\'g\'ri! ❌');
        }
        
        matchGameState.selectedCards = [];
    }
}

// Game 2: Hidden Word
function startHiddenWordGame() {
    const area = document.getElementById('playLearnGameArea');
    if (!area) return;
    
    const words = ['BEAUTIFUL', 'NECESSARY', 'PRONOUNCE', 'ALGORITHM', 'MNEMONIC'];
    const word = words[Math.floor(Math.random() * words.length)];
    const scrambled = word.split('').sort(() => Math.random() - 0.5).join(' ');
    
    area.innerHTML = `
        <div class="mini-game-header">
            <h3>${t('games.hiddenWord')}</h3>
        </div>
        <div class="hidden-word-game">
            <div class="scrambled-letters">${scrambled}</div>
            <input type="text" id="hiddenWordInput" class="game-input" placeholder="So'zni toping..." maxlength="${word.length}">
            <button class="btn-game-check" onclick="checkHiddenWord('${word}')">Tekshirish</button>
            <div id="hiddenWordResult"></div>
        </div>
    `;
}

function checkHiddenWord(correctWord) {
    const input = document.getElementById('hiddenWordInput');
    const result = document.getElementById('hiddenWordResult');
    
    if (input.value.toUpperCase() === correctWord) {
        result.innerHTML = '<span class="correct-text">To\'g\'ri! 🎉</span>';
        showToast('Ajoyib! ✅');
    } else {
        result.innerHTML = '<span class="incorrect-text">Noto\'g\'ri, qayta urinib ko\'ring</span>';
        showToast('Qayta urinib ko\'ring ❌');
    }
}

// ── MNEMONIKA AI GENERATION ──

let currentGeneratedWord = null;
let isCardFlipped = false;

// Helper function to parse markdown bold (**text**) to HTML
function parseMarkdownBold(text) {
    if (!text) return '';
    return text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
}

// Enter key event listener for word input
document.addEventListener('DOMContentLoaded', function() {
    const wordInput = document.getElementById('wordInput');
    if (wordInput) {
        wordInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                if (isCardFlipped) {
                    flipCardBack();
                } else {
                    flipAndGenerate();
                }
            }
        });
    }
    
    // Add click handler to flip card front
    const flipCard = document.querySelector('.flip-card');
    if (flipCard) {
        flipCard.addEventListener('click', function(e) {
            // Don't flip if clicking on buttons inside the card
            if (e.target.closest('button') || e.target.closest('.save-word-row')) {
                return;
            }
            
            if (!isCardFlipped && currentGeneratedWord) {
                flipCardForward();
            }
        });
    }
});

function flipCardForward() {
    const flipCard = document.querySelector('.flip-card');
    flipCard.classList.add('flipped');
    isCardFlipped = true;
}

function flipCardBack(event) {
    if (event) {
        event.stopPropagation();
    }
    
    const flipCard = document.querySelector('.flip-card');
    flipCard.classList.remove('flipped');
    isCardFlipped = false;
    
    // Clear the input after a short delay
    setTimeout(() => {
        document.getElementById('wordInput').value = '';
        document.getElementById('wordInput').focus();
    }, 400);
}

// ── FLIP AND GENERATE (PUBLIC - NO AUTH REQUIRED) ──

async function flipAndGenerate() {
    const wordInput = document.getElementById('wordInput');
    const word = wordInput.value.trim();
    
    if (!word) {
        showToast('Iltimos, so\'z kiriting! ⚠️');
        return;
    }
    
    // Reset flip state
    const flipCard = document.querySelector('.flip-card');
    flipCard.classList.remove('flipped');
    isCardFlipped = false;
    
    // Show loading state
    const btnCreate = document.querySelector('.btn-create');
    const originalBtnText = btnCreate.textContent;
    btnCreate.textContent = 'Yaratilmoqda...';
    btnCreate.disabled = true;
    flipCard.classList.add('loading');
    
    // Show loader on card front
    const uzDisplay = document.getElementById('uzDisplay');
    const imgPlaceholder = document.getElementById('imgPlaceholder');
    const originalUzText = uzDisplay.textContent;
    uzDisplay.textContent = 'Yuklanmoqda...';
    if (imgPlaceholder) {
        imgPlaceholder.className = 'fas fa-spinner fa-spin';
    }
    
    try {
        // Call the API (public endpoint - no auth required)
        const response = await fetch('/api/generate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ word: word })
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        
        // Store current word for saving (including image)
        currentGeneratedWord = {
            word_en: data.word_en,
            word_uz: data.word_uz,
            mnemonic: data.mnemonic,
            example: data.example,
            image_url: data.image_url
        };
        
        // Update card front (Uzbek translation)
        uzDisplay.textContent = data.word_uz;
        
        // Update image on card front
        const enImage = document.getElementById('enImage');
        if (data.image_url && enImage) {
            enImage.src = data.image_url;
            enImage.style.display = 'block';
            enImage.alt = data.word_en;
            if (imgPlaceholder) {
                imgPlaceholder.style.display = 'none';
            }
        } else if (imgPlaceholder) {
            imgPlaceholder.className = 'fas fa-image placeholder-icon';
            imgPlaceholder.style.display = 'block';
        }
        
        // Update card back (English word, mnemonic, example)
        document.getElementById('enDisplay').textContent = data.word_en;
        
        // Parse markdown bold in mnemonic and example
        const parsedMnemonic = parseMarkdownBold(data.mnemonic);
        const parsedExample = parseMarkdownBold(data.example);
        
        // Format the mnemonic with example - improved typography
        const mnemonicDisplay = document.getElementById('mnDisplay');
        mnemonicDisplay.innerHTML = `
            <div style="margin-bottom: 20px; font-size: 1.15rem; line-height: 1.8;">
                <strong style="color: var(--neon-cyan); display: block; margin-bottom: 8px; font-size: 1rem;">Mnemonika:</strong>
                <span style="color: rgba(255,255,255,0.95);">${parsedMnemonic}</span>
            </div>
            <div style="border-top: 1px solid rgba(0,242,255,0.3); padding-top: 20px;">
                <strong style="color: var(--neon-purple); display: block; margin-bottom: 8px; font-size: 1rem;">Example:</strong>
                <em style="color: rgba(255,255,255,0.85); font-size: 1.1rem; display: block; font-style: italic;">"${parsedExample}"</em>
            </div>
        `;
        
        // Show save button
        const saveRow = document.getElementById('saveWordRow');
        if (saveRow) {
            saveRow.style.display = 'block';
        }
        
        // Remove loading class and flip the card after a short delay
        flipCard.classList.remove('loading');
        
        setTimeout(() => {
            flipCardForward();
            showToast('Mnemonika yaratildi! ✨');
        }, 400);
        
    } catch (error) {
        console.error('Generation error:', error);
        showToast('Xatolik yuz berdi! Qayta urinib ko\'ring. ❌');
        uzDisplay.textContent = originalUzText;
        if (imgPlaceholder) {
            imgPlaceholder.className = 'fas fa-image placeholder-icon';
        }
        flipCard.classList.remove('loading');
    } finally {
        // Reset button state
        btnCreate.textContent = originalBtnText;
        btnCreate.disabled = false;
    }
}

async function saveCurrentWord() {
    if (!currentGeneratedWord) {
        showToast('Saqlash uchun so\'z yo\'q! ⚠️');
        return;
    }
    
    try {
        const token = localStorage.getItem('access_token');
        if (!token) {
            showToast('Iltimos, avval tizimga kiring! 🔒');
            showSection('auth');
            return;
        }
        
        const response = await fetch('/api/words', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                word_en: currentGeneratedWord.word_en,
                word_uz: currentGeneratedWord.word_uz,
                mnemonic: currentGeneratedWord.mnemonic + '\n\nExample: ' + currentGeneratedWord.example
            })
        });
        
        if (response.ok) {
            showToast('So\'z saqlandi! ✅');
        } else if (response.status === 401) {
            showToast('Tizimga kirish talab qilinadi! 🔒');
            showSection('auth');
        } else {
            throw new Error('Save failed');
        }
    } catch (error) {
        console.error('Save error:', error);
        showToast('Saqlashda xatolik! ❌');
    }
}

// Toast notification helper
function showToast(message) {
    // Remove existing toast
    const existingToast = document.querySelector('.toast-notification');
    if (existingToast) {
        existingToast.remove();
    }
    
    // Create new toast
    const toast = document.createElement('div');
    toast.className = 'toast-notification';
    toast.textContent = message;
    toast.style.cssText = `
        position: fixed;
        bottom: 100px;
        left: 50%;
        transform: translateX(-50%);
        background: linear-gradient(135deg, var(--neon-cyan), var(--neon-purple));
        color: #0a0a0f;
        padding: 16px 32px;
        border-radius: 50px;
        font-weight: 700;
        font-size: 0.95rem;
        z-index: 10000;
        box-shadow: 0 10px 40px rgba(0, 242, 255, 0.3);
        animation: slideUp 0.3s ease;
    `;
    
    document.body.appendChild(toast);
    
    // Remove after 3 seconds
    setTimeout(() => {
        toast.style.animation = 'slideDown 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Add CSS animation for toast
const toastStyle = document.createElement('style');
toastStyle.textContent = `
    @keyframes slideUp {
        from { transform: translateX(-50%) translateY(100px); opacity: 0; }
        to { transform: translateX(-50%) translateY(0); opacity: 1; }
    }
    @keyframes slideDown {
        from { transform: translateX(-50%) translateY(0); opacity: 1; }
        to { transform: translateX(-50%) translateY(100px); opacity: 0; }
`;
document.head.appendChild(toastStyle);

// ── AUTHENTICATION SYSTEM ──

// Check auth status on page load
document.addEventListener('DOMContentLoaded', function() {
    checkAuthStatus();
});

function checkAuthStatus() {
    const token = localStorage.getItem('access_token');
    const username = localStorage.getItem('username');
    
    if (token && username) {
        // User is logged in
        showLoggedInUI(username);
    } else {
        // User is logged out
        showLoggedOutUI();
    }
}

function showLoggedInUI(username) {
    const navAuth = document.getElementById('navAuth');
    const navUser = document.getElementById('navUser');
    const navUsername = document.getElementById('navUsername');
    
    if (navAuth) navAuth.style.display = 'none';
    if (navUser) {
        navUser.style.display = 'flex';
        if (navUsername) navUsername.textContent = username;
    }
}

function showLoggedOutUI() {
    const navAuth = document.getElementById('navAuth');
    const navUser = document.getElementById('navUser');
    
    if (navAuth) navAuth.style.display = 'block';
    if (navUser) navUser.style.display = 'none';
}

async function doLogin() {
    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value.trim();
    
    if (!email || !password) {
        showAuthError('authError', 'Email va parolni kiriting!');
        return;
    }
    
    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            // Store token and username
            localStorage.setItem('access_token', data.access_token);
            localStorage.setItem('username', data.username);
            
            showToast(`Xush kelibsiz, ${data.username}! 👋`);
            showLoggedInUI(data.username);
            showSection('app');
        } else {
            showAuthError('authError', data.detail || 'Login xatolik!');
        }
    } catch (error) {
        showAuthError('authError', 'Serverga ulanishda xatolik!');
    }
}

async function doRegister() {
    const username = document.getElementById('regUsername').value.trim();
    const email = document.getElementById('regEmail').value.trim();
    const password = document.getElementById('regPassword').value.trim();
    
    if (!username || !email || !password) {
        showAuthError('authError', 'Barcha maydonlarni to\'ldiring!');
        return;
    }
    
    if (password.length < 6) {
        showAuthError('authError', 'Parol kamida 6 ta belgi bo\'lishi kerak!');
        return;
    }
    
    try {
        const response = await fetch('/api/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, email, password })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showToast('Muvaffaqiyatli ro\'yxatdan o\'tdingiz! Endi kiring.');
            switchAuthForm('login');
        } else {
            showAuthError('authError', data.detail || 'Ro\'yxatdan o\'tishda xatolik!');
        }
    } catch (error) {
        showAuthError('authError', 'Serverga ulanishda xatolik!');
    }
}

function logout() {
    localStorage.removeItem('access_token');
    localStorage.removeItem('username');
    showLoggedOutUI();
    showToast('Tizimdan chiqdingiz! 👋');
    showSection('home');
}

function showAuthError(elementId, message) {
    const errorEl = document.getElementById(elementId);
    if (errorEl) {
        errorEl.textContent = message;
        errorEl.style.display = 'block';
        setTimeout(() => {
            errorEl.style.display = 'none';
        }, 5000);
    }
}

function clearAuthError(elementId) {
    const errorEl = document.getElementById(elementId);
    if (errorEl) {
        errorEl.style.display = 'none';
    }
}

function switchAuthForm(form) {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    
    if (form === 'login') {
        loginForm.style.display = 'block';
        registerForm.style.display = 'none';
    } else {
        loginForm.style.display = 'none';
        registerForm.style.display = 'block';
    }
    clearAuthError('authError');
}

// ── FLIP AND GENERATE (PUBLIC - ZERO BARRIERS) ──

async function flipAndGenerate() {
    const wordInput = document.getElementById('wordInput');
    const word = wordInput.value.trim();
    
    if (!word) {
        showToast('Iltimos, so\'z kiriting! ⚠️');
        return;
    }
    
    // ... existing code continues
}

// ── MINI GAME MODAL FUNCTIONS ──

function startMiniGame(gameType) {
    const modal = document.getElementById('miniGameModal');
    if (!modal) return;
    
    modal.style.display = 'flex';
    
    if (gameType === 'match') {
        startMatchGame();
    } else if (gameType === 'hidden') {
        startHiddenWordGame();
    }
}

function closeMiniGame() {
    const modal = document.getElementById('miniGameModal');
    if (modal) {
        modal.style.display = 'none';
    }
    
    // Reset game area
    const area = document.getElementById('playLearnGameArea');
    if (area) {
        area.innerHTML = '';
    }
}

// ── MNEMONIKA MINI-EXERCISE FUNCTIONS ──

const exerciseWords = {
    acronym: ['kompyuter', 'telefon', 'maktab', 'kitob', 'daraxt', 'bulut', 'oyna', 'stul'],
    visualization: ['mushuk', 'kuchuk', 'olma', 'banan', 'quyosh', 'oy', 'yulduz', 'samolyot'],
    association: ['yomgir', 'gul', 'bahor', 'kuz', 'dengiz', 'tog', 'daryo', 'shahar'],
    rhyme: ['uy', 'moy', 'dunyo', 'osmon', 'yer', 'suv', 'otash', 'havo']
};

function startAcronymExercise() {
    const area = document.getElementById('miniExerciseArea');
    const content = document.getElementById('exerciseContent');
    if (!area || !content) return;
    
    const words = exerciseWords.acronym;
    const word = words[Math.floor(Math.random() * words.length)];
    
    content.innerHTML = `
        <h4><i class="fas fa-font"></i> Akronim Yaratish</h4>
        <p>Quyidagi so'z uchun bosh harflardan yangi so'z yarating:</p>
        <div class="exercise-word">${word.toUpperCase()}</div>
        <div class="exercise-input-area">
            <input type="text" id="acronymInput" placeholder="Akronim kiriting..." maxlength="10">
            <button onclick="checkAcronym('${word}')" class="btn-check">Tekshirish</button>
        </div>
        <div id="acronymResult" class="exercise-result"></div>
        <div class="exercise-hint">Misol: KOMPYUTER → KOMP</div>
    `;
    
    area.style.display = 'block';
    area.scrollIntoView({ behavior: 'smooth' });
}

function checkAcronym(originalWord) {
    const input = document.getElementById('acronymInput').value.trim().toUpperCase();
    const resultDiv = document.getElementById('acronymResult');
    
    if (!input) {
        resultDiv.innerHTML = '<span class="result-error">Iltimos, akronim kiriting!</span>';
        return;
    }
    
    // Check if acronym uses letters from the original word
    const originalLetters = originalWord.toUpperCase().split('');
    const inputLetters = input.split('');
    
    let valid = true;
    for (let letter of inputLetters) {
        if (!originalLetters.includes(letter)) {
            valid = false;
            break;
        }
    }
    
    if (valid && input.length >= 2) {
        resultDiv.innerHTML = '<span class="result-success">Ajoyib! Yaxshi akronim! 🎉</span>';
        setTimeout(() => startAcronymExercise(), 2000);
    } else {
        resultDiv.innerHTML = '<span class="result-error">Asosiy so\'zdagi harflardan foydalaning!</span>';
    }
}

function startVisualizationExercise() {
    const area = document.getElementById('miniExerciseArea');
    const content = document.getElementById('exerciseContent');
    if (!area || !content) return;
    
    const words = exerciseWords.visualization;
    const word = words[Math.floor(Math.random() * words.length)];
    
    content.innerHTML = `
        <h4><i class="fas fa-image"></i> Tasavvur Qilish</h4>
        <p>Quyidagi so'zni katta, g'alati yoki rang-barang tasvirga aylantiring:</p>
        <div class="exercise-word">${word.toUpperCase()}</div>
        <div class="exercise-visualization">
            <p><strong>Misol:</strong></p>
            <p>"${word}" → Katta ${word} o'yaling, u kulrang rangda, osmonda uchib yuribdi!</p>
        </div>
        <div class="exercise-input-area">
            <textarea id="visualInput" placeholder="Tasavvuringizni yozing..." rows="3"></textarea>
            <button onclick="checkVisualization()" class="btn-check">Tasdiqlash</button>
        </div>
        <div id="visualResult" class="exercise-result"></div>
    `;
    
    area.style.display = 'block';
    area.scrollIntoView({ behavior: 'smooth' });
}

function checkVisualization() {
    const input = document.getElementById('visualInput').value.trim();
    const resultDiv = document.getElementById('visualResult');
    
    if (input.length < 10) {
        resultDiv.innerHTML = '<span class="result-error">Batafsilroq tasavvur qiling!</span>';
        return;
    }
    
    resultDiv.innerHTML = '<span class="result-success">Ajoyib tasavvur! Xotirangiz mustahkamlandi! 🧠✨</span>';
    setTimeout(() => startVisualizationExercise(), 2000);
}

function startAssociationExercise() {
    const area = document.getElementById('miniExerciseArea');
    const content = document.getElementById('exerciseContent');
    if (!area || !content) return;
    
    const words = exerciseWords.association;
    const word1 = words[Math.floor(Math.random() * words.length)];
    let word2 = words[Math.floor(Math.random() * words.length)];
    while (word1 === word2) {
        word2 = words[Math.floor(Math.random() * words.length)];
    }
    
    content.innerHTML = `
        <h4><i class="fas fa-link"></i> Assotsiatsiya</h4>
        <p>Bu ikki so'zni qanday bog'lash mumkin?</p>
        <div class="exercise-words-pair">
            <span>${word1.toUpperCase()}</span>
            <i class="fas fa-arrows-alt-h"></i>
            <span>${word2.toUpperCase()}</span>
        </div>
        <div class="exercise-input-area">
            <input type="text" id="assocInput" placeholder="Assotsiatsiyangizni yozing...">
            <button onclick="checkAssociation()" class="btn-check">Tekshirish</button>
        </div>
        <div id="assocResult" class="exercise-result"></div>
        <div class="exercise-hint">Misol: Bahor va gul → Bahorda gullar ochiladi</div>
    `;
    
    area.style.display = 'block';
    area.scrollIntoView({ behavior: 'smooth' });
}

function checkAssociation() {
    const input = document.getElementById('assocInput').value.trim();
    const resultDiv = document.getElementById('assocResult');
    
    if (input.length < 5) {
        resultDiv.innerHTML = '<span class="result-error">Bog\'lashni batafsilroq tushuntiring!</span>';
        return;
    }
    
    resultDiv.innerHTML = '<span class="result-success">Ajoyib assotsiatsiya! Endi bu so\'zlarni unutmaslikka oson! 🔗</span>';
    setTimeout(() => startAssociationExercise(), 2000);
}

function startRhymeExercise() {
    const area = document.getElementById('miniExerciseArea');
    const content = document.getElementById('exerciseContent');
    if (!area || !content) return;
    
    const words = exerciseWords.rhyme;
    const word = words[Math.floor(Math.random() * words.length)];
    
    content.innerHTML = `
        <h4><i class="fas fa-music"></i> Qofiya</h4>
        <p>Quyidagi so'z bilan qofiyalashadigan so'z toping:</p>
        <div class="exercise-word">${word.toUpperCase()}</div>
        <div class="exercise-input-area">
            <input type="text" id="rhymeInput" placeholder="Qofiya so'zini kiriting...">
            <button onclick="checkRhyme('${word}')" class="btn-check">Tekshirish</button>
        </div>
        <div id="rhymeResult" class="exercise-result"></div>
        <div class="exercise-hint">Misol: UY → MOY, DUNYO</div>
    `;
    
    area.style.display = 'block';
    area.scrollIntoView({ behavior: 'smooth' });
}

function checkRhyme(originalWord) {
    const input = document.getElementById('rhymeInput').value.trim().toLowerCase();
    const resultDiv = document.getElementById('rhymeResult');
    
    if (!input) {
        resultDiv.innerHTML = '<span class="result-error">So\'z kiriting!</span>';
        return;
    }
    
    // Simple rhyme check - last 2-3 letters should match
    const originalEnd = originalWord.toLowerCase().slice(-2);
    const inputEnd = input.slice(-2);
    
    if (inputEnd === originalEnd && input !== originalWord.toLowerCase()) {
        resultDiv.innerHTML = '<span class="result-success">Ajoyib qofiya! 🎵</span>';
        setTimeout(() => startRhymeExercise(), 1500);
    } else {
        resultDiv.innerHTML = '<span class="result-error">Yana bir bor urinib ko\'ring! Oxirgi harflar o\'xshashi kerak.</span>';
    }
}

function closeMiniExercise() {
    const area = document.getElementById('miniExerciseArea');
    if (area) {
        area.style.display = 'none';
    }
}

// ── MEMORY GAME IMPLEMENTATION ──

let memoryGameState = {
    cards: [],
    flippedCards: [],
    matchedPairs: 0,
    totalPairs: 8,
    moves: 0,
    timer: null,
    seconds: 0,
    isLocked: false
};

const memoryWords = [
    { en: 'Apple', uz: 'Olma', icon: '🍎' },
    { en: 'Book', uz: 'Kitob', icon: '📚' },
    { en: 'Sun', uz: 'Quyosh', icon: '☀️' },
    { en: 'Water', uz: 'Suv', icon: '💧' },
    { en: 'Tree', uz: 'Daraxt', icon: '🌳' },
    { en: 'House', uz: 'Uy', icon: '🏠' },
    { en: 'Cat', uz: 'Mushuk', icon: '🐱' },
    { en: 'Dog', uz: 'Kuchuk', icon: '🐕' }
];

function initializeMemoryGame() {
    const grid = document.getElementById('memoryGameGrid');
    if (!grid) return;
    
    // Reset state
    memoryGameState = {
        cards: [],
        flippedCards: [],
        matchedPairs: 0,
        totalPairs: 8,
        moves: 0,
        timer: null,
        seconds: 0,
        isLocked: false
    };
    
    // Clear timer
    if (memoryGameState.timer) {
        clearInterval(memoryGameState.timer);
    }
    
    // Create card pairs
    const cards = [];
    memoryWords.forEach((word, index) => {
        // English card
        cards.push({
            id: index * 2,
            content: word.en,
            icon: word.icon,
            pairId: index,
            isFlipped: false,
            isMatched: false
        });
        // Uzbek card
        cards.push({
            id: index * 2 + 1,
            content: word.uz,
            icon: word.icon,
            pairId: index,
            isFlipped: false,
            isMatched: false
        });
    });
    
    // Shuffle cards
    memoryGameState.cards = shuffleArray(cards);
    
    // Render grid
    renderMemoryGrid();
    
    // Update stats
    updateMemoryStats();
    
    // Start timer
    startMemoryTimer();
}

function shuffleArray(array) {
    const newArray = [...array];
    for (let i = newArray.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
    }
    return newArray;
}

function renderMemoryGrid() {
    const grid = document.getElementById('memoryGameGrid');
    if (!grid) return;
    
    grid.innerHTML = '';
    
    memoryGameState.cards.forEach(card => {
        const cardEl = document.createElement('div');
        cardEl.className = `memory-card ${card.isFlipped ? 'flipped' : ''} ${card.isMatched ? 'matched' : ''}`;
        cardEl.dataset.id = card.id;
        cardEl.onclick = () => flipMemoryCard(card.id);
        
        cardEl.innerHTML = `
            <div class="memory-card-inner">
                <div class="memory-card-front">
                    <span class="memory-icon">?</span>
                </div>
                <div class="memory-card-back">
                    <span class="memory-icon">${card.icon}</span>
                    <span class="memory-text">${card.content}</span>
                </div>
            </div>
        `;
        
        grid.appendChild(cardEl);
    });
}

function flipMemoryCard(cardId) {
    if (memoryGameState.isLocked) return;
    
    const card = memoryGameState.cards.find(c => c.id === cardId);
    if (!card || card.isFlipped || card.isMatched) return;
    
    // Flip the card
    card.isFlipped = true;
    memoryGameState.flippedCards.push(card);
    
    // Update UI
    const cardEl = document.querySelector(`.memory-card[data-id="${cardId}"]`);
    if (cardEl) cardEl.classList.add('flipped');
    
    // Check for match
    if (memoryGameState.flippedCards.length === 2) {
        memoryGameState.moves++;
        updateMemoryStats();
        checkMemoryMatch();
    }
}

function checkMemoryMatch() {
    memoryGameState.isLocked = true;
    const [card1, card2] = memoryGameState.flippedCards;
    
    if (card1.pairId === card2.pairId) {
        // Match found
        card1.isMatched = true;
        card2.isMatched = true;
        memoryGameState.matchedPairs++;
        memoryGameState.flippedCards = [];
        memoryGameState.isLocked = false;
        
        // Update UI
        setTimeout(() => {
            const el1 = document.querySelector(`.memory-card[data-id="${card1.id}"]`);
            const el2 = document.querySelector(`.memory-card[data-id="${card2.id}"]`);
            if (el1) el1.classList.add('matched');
            if (el2) el2.classList.add('matched');
            
            updateMemoryStats();
            
            // Check win
            if (memoryGameState.matchedPairs === memoryGameState.totalPairs) {
                clearInterval(memoryGameState.timer);
                setTimeout(() => {
                    showToast(`Tabriklaymiz! ${memoryGameState.moves} harakatda g'alaba qozdingiz! 🎉`);
                }, 500);
            }
        }, 500);
    } else {
        // No match
        setTimeout(() => {
            card1.isFlipped = false;
            card2.isFlipped = false;
            
            const el1 = document.querySelector(`.memory-card[data-id="${card1.id}"]`);
            const el2 = document.querySelector(`.memory-card[data-id="${card2.id}"]`);
            if (el1) el1.classList.remove('flipped');
            if (el2) el2.classList.remove('flipped');
            
            memoryGameState.flippedCards = [];
            memoryGameState.isLocked = false;
        }, 1000);
    }
}

function updateMemoryStats() {
    const movesEl = document.getElementById('memoryMoves');
    const pairsEl = document.getElementById('memoryPairs');
    
    if (movesEl) movesEl.textContent = memoryGameState.moves;
    if (pairsEl) pairsEl.textContent = `${memoryGameState.matchedPairs}/${memoryGameState.totalPairs}`;
}

function startMemoryTimer() {
    const timeEl = document.getElementById('memoryTime');
    if (!timeEl) return;
    
    memoryGameState.timer = setInterval(() => {
        memoryGameState.seconds++;
        const minutes = Math.floor(memoryGameState.seconds / 60);
        const seconds = memoryGameState.seconds % 60;
        timeEl.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }, 1000);
}