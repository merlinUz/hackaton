from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text, JSON
from sqlalchemy.orm import relationship
from datetime import datetime
from database import Base

class User(Base):
    __tablename__ = "users"

    id         = Column(Integer, primary_key=True, index=True)
    username   = Column(String(50), unique=True, index=True, nullable=False)
    email      = Column(String(100), unique=True, index=True, nullable=False)
    hashed_password = Column(String(200), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    words = relationship("LearnedWord", back_populates="owner", cascade="all, delete")
    history = relationship("UserHistory", back_populates="user", cascade="all, delete")


class LearnedWord(Base):
    __tablename__ = "learned_words"

    id          = Column(Integer, primary_key=True, index=True)
    user_id     = Column(Integer, ForeignKey("users.id"), nullable=False)
    word_en     = Column(String(100), nullable=False)
    word_uz     = Column(String(100), nullable=False)
    mnemonic    = Column(Text, nullable=False)
    image_url   = Column(String(300), nullable=True)
    learned_at  = Column(DateTime, default=datetime.utcnow)

    owner = relationship("User", back_populates="words")


class UserHistory(Base):
    __tablename__ = "user_history"

    id          = Column(Integer, primary_key=True, index=True)
    user_id     = Column(Integer, ForeignKey("users.id"), nullable=False)
    action      = Column(String(100), nullable=False)  # e.g., 'registered', 'login', 'word_generated', 'game_played'
    details     = Column(JSON, nullable=True)  # Store additional data as JSON
    created_at  = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="history")