#!/bin/bash

# Mnemonika AI Server Startup Script
# This script starts the FastAPI server with sudo privileges

echo "Starting Mnemonika AI Server..."

# Check if uvicorn is installed
if ! python3 -c "import uvicorn" 2>/dev/null; then
    echo "Installing required packages..."
    sudo python3 -m pip install -r requirements.txt
fi

# Kill any existing uvicorn processes
echo "Stopping existing server processes..."
sudo pkill -f uvicorn

# Wait a moment for processes to stop
sleep 2

# Start the server
echo "Starting server on http://localhost:8000"
sudo python3 -m uvicorn main:app --reload --host 0.0.0.0 --port 8000
