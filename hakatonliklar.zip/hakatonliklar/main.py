from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from pydantic import BaseModel, EmailStr
from typing import Optional
import os

from database import engine, get_db, Base
import models, auth
from gemini_service import get_gemini_service
from pexels_service import get_pexels_service

# DB jadvallarini yaratish
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Mnemonika AI API")

# CORS — frontend bilan ishlash uchun
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Pydantic sxemalar ──
class RegisterRequest(BaseModel):
    username: str
    email: str
    password: str

class LoginRequest(BaseModel):
    email: str
    password: str

class WordSaveRequest(BaseModel):
    word_en:   str
    word_uz:   str
    mnemonic:  str
    image_url: Optional[str] = None

class TokenResponse(BaseModel):
    access_token: str
    token_type:   str
    username:     str

class GenerateRequest(BaseModel):
    word: str
    topic: Optional[str] = "general"
    language: Optional[str] = "uz"

class GenerateResponse(BaseModel):
    word_en: str
    word_uz: str
    mnemonic: str
    example: str
    image_url: Optional[str] = None

# ── GEMINI GENERATE ENDPOINT (PUBLIC) ──

@app.post("/api/generate", response_model=GenerateResponse)
def generate_mnemonic(req: GenerateRequest):
    """
    Generate a mnemonic story, example, and fetch an image for an English word
    using Gemini AI and Pexels API. Public endpoint - no authentication required.
    """
    try:
        # Generate mnemonic with Gemini
        gemini = get_gemini_service()
        result = gemini.generate_mnemonic(req.word.strip())
        
        # Fetch image from Pexels (if API key is configured)
        image_url = None
        try:
            pexels = get_pexels_service()
            image_url = pexels.get_image_for_word(req.word.strip())
        except ValueError:
            # Pexels not configured, skip image fetching
            pass
        except Exception as e:
            print(f"Image fetching error: {e}")
        
        return GenerateResponse(
            word_en=result["word_en"],
            word_uz=result["word_uz"],
            mnemonic=result["mnemonic"],
            example=result["example"],
            image_url=image_url
        )
    except ValueError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Generation failed: {str(e)}")

# ── AUTH ENDPOINTS ──

@app.post("/api/register", status_code=201)
def register(req: RegisterRequest, db: Session = Depends(get_db)):
    # Email mavjudmi?
    if db.query(models.User).filter(models.User.email == req.email).first():
        raise HTTPException(status_code=400, detail="Bu email allaqachon ro'yxatdan o'tgan")
    # Username mavjudmi?
    if db.query(models.User).filter(models.User.username == req.username).first():
        raise HTTPException(status_code=400, detail="Bu foydalanuvchi nomi band")
    # Parol uzunligi
    if len(req.password) < 6:
        raise HTTPException(status_code=400, detail="Parol kamida 6 ta belgi bo'lishi kerak")

    user = models.User(
        username=req.username,
        email=req.email,
        hashed_password=auth.hash_password(req.password)
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    
    # Save registration history
    history = models.UserHistory(
        user_id=user.id,
        action="registered",
        details={"username": user.username, "email": user.email}
    )
    db.add(history)
    db.commit()
    
    return {"message": "Muvaffaqiyatli ro'yxatdan o'tdingiz!"}


@app.post("/api/login", response_model=TokenResponse)
def login(req: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email == req.email).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Akkaunt topilmadi 😟"
        )
    if not auth.verify_password(req.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Akkaunt topilmadi")
    token = auth.create_token({"sub": user.email})
    
    # Save login history
    history = models.UserHistory(
        user_id=user.id,
        action="login",
        details={"username": user.username}
    )
    db.add(history)
    db.commit()
    
    return {"access_token": token, "token_type": "bearer", "username": user.username}


@app.get("/api/me")
def get_me(current_user: models.User = Depends(auth.get_current_user)):
    return {
        "id":       current_user.id,
        "username": current_user.username,
        "email":    current_user.email,
    }

# ── SO'ZLAR ENDPOINTS ──

@app.post("/api/words", status_code=201)
def save_word(
    req: WordSaveRequest,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    # Bir xil so'z ikki marta saqlanmasin
    existing = db.query(models.LearnedWord).filter(
        models.LearnedWord.user_id == current_user.id,
        models.LearnedWord.word_en == req.word_en.lower()
    ).first()
    if existing:
        # Yangilash
        existing.word_uz   = req.word_uz
        existing.mnemonic  = req.mnemonic
        existing.image_url = req.image_url
        db.commit()
        return {"message": "So'z yangilandi"}

    word = models.LearnedWord(
        user_id   = current_user.id,
        word_en   = req.word_en.lower(),
        word_uz   = req.word_uz,
        mnemonic  = req.mnemonic,
        image_url = req.image_url
    )
    db.add(word)
    db.commit()
    
    # Save word added to history
    history = models.UserHistory(
        user_id=current_user.id,
        action="word_saved",
        details={"word_en": req.word_en, "word_uz": req.word_uz}
    )
    db.add(history)
    db.commit()
    
    return {"message": "So'z saqlandi"}


@app.get("/api/words")
def get_words(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    words = db.query(models.LearnedWord)\
              .filter(models.LearnedWord.user_id == current_user.id)\
              .order_by(models.LearnedWord.learned_at.desc())\
              .all()
    return [
        {
            "id":         w.id,
            "word_en":    w.word_en,
            "word_uz":    w.word_uz,
            "mnemonic":   w.mnemonic,
            "image_url":  w.image_url,
            "learned_at": w.learned_at.isoformat()
        }
        for w in words
    ]


@app.get("/api/history")
def get_user_history(
    limit: int = 50,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    """Retrieve user activity history"""
    history = db.query(models.UserHistory).filter(
        models.UserHistory.user_id == current_user.id
    ).order_by(models.UserHistory.created_at.desc()).limit(limit).all()
    
    return [
        {
            "id": h.id,
            "action": h.action,
            "details": h.details,
            "created_at": h.created_at.isoformat()
        }
        for h in history
    ]


@app.delete("/api/words/{word_id}")
def delete_word(
    word_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    word = db.query(models.LearnedWord).filter(
        models.LearnedWord.id == word_id,
        models.LearnedWord.user_id == current_user.id
    ).first()
    if not word:
        raise HTTPException(status_code=404, detail="So'z topilmadi")
    db.delete(word)
    db.commit()
    return {"message": "O'chirildi"}


# ── Static fayllar (frontend) ──
# Frontend fayllar shu papkada joylashgan
FRONTEND_DIR = os.path.dirname(__file__)

@app.get("/")
def serve_index():
    return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))

@app.get("/{full_path:path}")
def serve_static(full_path: str):
    file_path = os.path.join(FRONTEND_DIR, full_path)
    if os.path.exists(file_path) and os.path.isfile(file_path):
        # Determine media type
        if full_path.endswith('.js'):
            media_type = 'application/javascript'
        elif full_path.endswith('.css'):
            media_type = 'text/css'
        elif full_path.endswith('.png'):
            media_type = 'image/png'
        elif full_path.endswith('.jpg') or full_path.endswith('.jpeg'):
            media_type = 'image/jpeg'
        elif full_path.endswith('.ico'):
            media_type = 'image/x-icon'
        else:
            media_type = 'text/plain'
        
        return FileResponse(file_path, media_type=media_type)
    return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))