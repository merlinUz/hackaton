"""
Pexels API Service Module
Handles image fetching for visual mnemonics
"""

import os
import requests
from typing import Optional

class PexelsService:
    """Service for fetching relevant images from Pexels API"""
    
    BASE_URL = "https://api.pexels.com/v1"
    
    def __init__(self):
        self.api_key = os.getenv("PEXELS_API_KEY")
        if not self.api_key or self.api_key == "your_pexels_api_key_here":
            raise ValueError("PEXELS_API_KEY not configured in environment variables")
        
        self.headers = {
            "Authorization": self.api_key
        }
    
    def search_image(self, query: str, orientation: str = "square", size: str = "large") -> Optional[str]:
        """
        Search for an image on Pexels
        
        Args:
            query: Search query (e.g., the English word)
            orientation: Image orientation (landscape, portrait, square)
            size: Image size (large, medium, small)
            
        Returns:
            URL of the first matching image, or None if not found
        """
        try:
            params = {
                "query": query,
                "per_page": 1,
                "orientation": orientation
            }
            
            response = requests.get(
                f"{self.BASE_URL}/search",
                headers=self.headers,
                params=params,
                timeout=10
            )
            
            response.raise_for_status()
            data = response.json()
            
            if data.get("photos") and len(data["photos"]) > 0:
                photo = data["photos"][0]
                
                # Get appropriate size
                src = photo.get("src", {})
                if size == "large" and "large" in src:
                    return src["large"]
                elif size == "medium" and "medium" in src:
                    return src["medium"]
                else:
                    return src.get("original") or src.get("large2x") or src.get("large")
            
            return None
            
        except requests.exceptions.RequestException as e:
            print(f"Pexels API error: {e}")
            return None
        except Exception as e:
            print(f"Unexpected error fetching image: {e}")
            return None
    
    def get_image_for_word(self, word: str) -> Optional[str]:
        """
        Get a relevant image for an English word
        
        Args:
            word: The English word to search for
            
        Returns:
            URL of a relevant image, or None if not found
        """
        # Try searching with the word directly
        image_url = self.search_image(word, orientation="square", size="large")
        
        # If no result, try with "illustration" or "concept" appended
        if not image_url:
            image_url = self.search_image(f"{word} concept", orientation="square", size="large")
        
        return image_url

# Global service instance
_pexels_service = None

def get_pexels_service() -> PexelsService:
    """Get or create the Pexels service singleton"""
    global _pexels_service
    if _pexels_service is None:
        _pexels_service = PexelsService()
    return _pexels_service
